package com.tnsif.stringprograms;
// demo for compare to method

public class CompareTomethod {
	public static void main(String[] args) {
		String s1="Jagadeesh";
		String s2="Jagadeesh";
		String s3="Nisarga";
		
		System.out.println(s1.compareTo(s2));
		System.out.println(s1.compareTo(s3));
		System.out.println(s3.compareTo(s1));
		
	}

}
