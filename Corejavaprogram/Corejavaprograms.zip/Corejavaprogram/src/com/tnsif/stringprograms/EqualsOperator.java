package com.tnsif.stringprograms;

public class EqualsOperator {
	public static void main(String[] args) {
		String s1="Nisarga";
		String s2="Nisarga";
		String s3=new String("Nisarga");
		String s4="Ankitha";
		
		System.out.println(s1==s2);
		System.out.println(s1==s3);
		System.out.println(s1==s4);
	}

}
