package com.tnsif.superkeyword;
//demo for super method
class Company {
	void work() {
		System.out.println("employee is working");
	}
}
class Coworkingspace extends Company {
	void work() {
		System.out.println("Trainers is teaching java");
	}
	
	void display() {
		super.work();
		work() ;
	}
}
public class SuperMethoddemo {
	public static void main(String[] args) {
		Coworkingspace c=new Coworkingspace();
		c.display();
	}

}
