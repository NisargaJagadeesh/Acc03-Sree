package com.tnsif.superkeyword;
// demo for super variable

class Employee {
	String name="Nisarga";
}

class Trainer extends Employee {
	String name = "Rashmi";


void display() {
	System.out.println("child name :"+name);
	System.out.println("parent name :"+super.name);
}
}
public class SuperVariabledemo {
	public static void main(String[] args) {
		Trainer t=new Trainer ();
		t.display();
	}

}

